const initialFormState = {persons : []};

function saveData(state = initialFormState,action){
    switch(action.type){
        case 'STORE_INFO' :
            var updatedState = Object.assign({}, state,{
                persons:[
                    ...state.persons,
                    action.data.formValues
                ]
            })
            return updatedState;
        default:
            return state
    }
}
export default saveData;