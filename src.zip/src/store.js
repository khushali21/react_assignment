import { createStore } from 'redux';
import saveData from './reducers';
 
const store = createStore(saveData);

export default store;