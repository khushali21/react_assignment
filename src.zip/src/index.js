import React from 'react';
import ReactDOM from 'react-dom';
import renderPage from './form';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

ReactDOM.render(renderPage(), document.getElementById('root'));

