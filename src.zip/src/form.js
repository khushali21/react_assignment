import React from "react";
import store from './store';

class Form extends React.Component {

    constructor(){
        super();
        this.state = {
            form:{
                firstName:"",
                lastname:"",
                profilePicture:null,
                contact:"",
                email:"",
                address:""
            },
            formErrorMessage:{
                firstName:"",
                lastname:"",
                profilePicture:"",
                contact:"",
                email:"",
                address:""
            },
            formValidity:{
                firstName:false,
                lastname:false,
                contact:false,
                email:false,
                address:false,
                buttonActive:false
            },
            imageValidation:false,
            theInputKey:"",
            successMessage:"",
            errorMessage:""
        };
        this.baseState = this.state.form;
    }

    handleSubmit = (event) =>{
        event.preventDefault();
        var action = {
            type:'STORE_INFO',
            data:{
                formValues:this.state.form
            }
        }
        store.dispatch(action)
        this.setState({form:this.baseState,formValidity:{buttonActive:false},imageValidation:false})
        let randomString = Math.random().toString(36);

        this.setState({theInputKey: randomString});
    }

    handleChange = (event) =>{
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const {form} = this.state;
        this.setState({form : { ...form, [name]:value}});
        this.validateField(name,value);
    }

    onChangeHandler = event => {
        if (event.target.files.length !== 0) {
            const { form } = this.state;
            this.setState({ form: { ...form, profilePicture: URL.createObjectURL(event.target.files[0]) } });
            this.validateImage(event.target.files[0].type, event.target.files.length)
        }
        else {
            const { formErrors } = this.state;
            this.setState({ imageValidation: false, formErrors: { ...formErrors, profilePicture: "Image required" } });
        }
    }
    validateImage = (fileType, no) => {
        let fieldValidationErrors = this.state.formErrorMessage;
        let formValid = this.state.formValidity;
        const imgRegex = /jpeg|jpg|png/;
        if (no === "0") {
            fieldValidationErrors.profilePicture = "Image required";
            formValid.profilePicture = false;
        } else if (!fileType.match(imgRegex)) {
            fieldValidationErrors.profilePicture = "Invalid file type";
            formValid.profilePicture = false;
        } else {
            fieldValidationErrors.profilePicture = "";
            formValid.profilePicture = true;
        }
        this.setState({ formErrorMessage: fieldValidationErrors, imageValidation: formValid.profilePicture })
    }
    jsUcfirst = (string) => {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    validateField = (fieldName, value) => {
        this.setState({ errorMessage: '' })
        let fieldValidationErrors = this.state.formErrorMessage;
        let formValid = this.state.formValidity;

        switch (fieldName) {
            case "firstName":
                value = this.jsUcfirst(value)
                const nameRegex = /^([A-z]|[ ])+$/
                if (value === "") {
                    fieldValidationErrors.firstName = "field required";
                    formValid.firstName = false;
                } else if (!value.match(nameRegex)) {
                    fieldValidationErrors.firstName = "Customer Name must contain only Alphabets";
                    formValid.firstName = false;
                } else {
                    fieldValidationErrors.firstName = "";
                    formValid.firstName = true;
                }
                break;

            case "lastName":
                value = this.jsUcfirst(value)
                const lNameRegex = /^([A-z]|[ ])+$/
                if (value === "") {
                    fieldValidationErrors.lastName = "field required";
                    formValid.lastName = false;
                } else if (!value.match(lNameRegex)) {
                    fieldValidationErrors.lastName = "Customer Name must contain only Alphabets";
                    formValid.lastName = false;
                } else {
                    fieldValidationErrors.lastName = "";
                    formValid.lastName = true;
                }
                break;

            case "email":
                const emailRegex = /^[A-z][\w\W\d\D]+@[a-z]+\.com$/
                if (value === "") {
                    fieldValidationErrors.email = "field required";
                    formValid.email = false;
                } else if (!value.match(emailRegex)) {
                    fieldValidationErrors.email = "Eg - abc09@xyz.com";
                    formValid.email = false;
                } else {
                    fieldValidationErrors.email = "";
                    formValid.email = true;
                }
                break;

            case "contact":
                if (value === "") {
                    fieldValidationErrors.contact = "field required";
                    formValid.contact = false;
                } else {
                    fieldValidationErrors.contact = "";
                    formValid.contact = true;
                }
                break;

            case "address":
                if (value === "") {
                    fieldValidationErrors.address = "field required";
                    formValid.address = false;
                } else {
                    fieldValidationErrors.address = "";
                    formValid.address = true;
                }
                break;

            default:
                break;
        }
        formValid.buttonActive =
            formValid.address &&
            formValid.email &&
            formValid.firstName &&
            formValid.lastName &&
            formValid.contact
        this.setState({ formErrorMessage: fieldValidationErrors, formValidity: formValid, errorMessage: "" })
    }


    render() {
        return (
            <div className="row" style={{ backgroundColor: "#99ffeb" }}>
                <div className="col-md-3"></div>
                <div className="col-md-6">
                    <center>
                    <div style={{ color: "#1e7b1e" }}><strong>Form</strong></div>
                    </center>
                    <form onSubmit={this.handleSubmit}>
                    <div style={{backgroundColor:"#e6f9ff"}} className="container-fluid border border-success rounded">
                    <label className="text-danger mt-3 mb-3"><span aria-hidden="true" className="required">*</span>All fields are mandatory</label>
                        <div className="form-group">
                            <label className="text-success" htmlFor="firstName">First Name<span aria-hidden="true" className="required text-danger">*</span></label>
                            <input type="text" name="firstName" id = "firstName" value={this.state.form.firstName} onChange={this.handleChange} className="form-control" placeholder="First Name" required maxLength="15"></input>
                            <span name="firstNameError" className="text-danger">{this.state.formErrorMessage.firstName}</span>
                        </div>
                        <div className="form-group">
                            <label className="text-success" htmlFor="lastName">Last Name<span aria-hidden="true" className="required text-danger">*</span></label>
                            <input type="text" name="lastName" id="lastName" value={this.state.form.lastName} onChange={this.handleChange} className="form-control" placeholder="Last Name" required maxLength="15"></input>
                            <span name="lastNameError" className="text-danger">{this.state.formErrorMessage.lastName}</span>
                        </div>
                        <div className="form-group">
                            <label className="text-success" htmlFor="profilePicture">Picture<span aria-hidden="true" className="required text-danger">*</span></label><br/>
                            <input type="file" name="profilePicture"  id="profilePicture" accept=".png, .jpg, .jpeg" key={this.state.theInputKey || ''} onChange={this.onChangeHandler} required/>
                            <span name="ProfilePictureError" className="text-danger">{this.state.formErrorMessage.profilePicture}</span>
                        </div>
                        <div className="form-group">
                            <label className="text-success" htmlFor="contact" >Number<span aria-hidden="true" className="required text-danger">*</span></label>
                            <input type="tel" name="contact" id="contact" value={this.state.form.contact} onChange={this.handleChange} className="form-control" pattern="[0-9]{10}" placeholder="Contact Number" required></input>
                            <span name="contactError" className="text-danger">{this.state.formErrorMessage.contact}</span>
                        </div>
                        <div className="form-group">
                            <label className="text-success" htmlFor="email">Id<span aria-hidden="true" className="required text-danger">*</span></label>
                            <input type="email" name="email" id="email" value={this.state.form.email} onChange={this.handleChange} className="form-control" placeholder="Email" required ></input>
                            <span name="emailError" className="text-danger">{this.state.formErrorMessage.email}</span>
                        </div>
                        <div className="form-group">
                            <label className="text-success" htmlFor="address">Address<span aria-hidden="true" className="required text-danger">*</span></label>
                            <input type="text" maxLength="200" name="address" id="address" value={this.state.form.address} onChange={this.handleChange} className="form-control" placeholder="Address" required></input>
                            <span name="addressError" className="text-danger">{this.state.formErrorMessage.address}</span>
                        </div>
                        <button type="submit" onClick={this.update} disabled={!(this.state.formValidity.buttonActive && this.state.imageValidation)} className="button btn-success btn-block mb-4">Submit</button>
                        </div>
                    </form>   
                </div>
                <div className="col-md-3"></div>
            </div>
        )
    }
}
class Table extends React.Component {
    constructor() {
        super();
        this.state = {
            persons: []
        }
    }
    render() {
        store.subscribe(() => {
            // console.log(store.getState().persons)
            this.setState({ persons: store.getState().persons })
        })
        var rowArr = this.state.persons.map((per) => {
            return (
                <tr key={per.number}>
                    <td>{per.firstName}</td>
                    <td>{per.lastName}</td>
                    <td><img height="100px" width="100px" src={per.profilePicture} alt="ProfilePic" /></td>
                    <td>{per.contact}</td>
                    <td>{per.email}</td>
                    <td>{per.address}</td>
                </tr>
            )
        })
        return (
            <div className="container">
                {rowArr.length !== 0 ?
                    <table className="table table-striped border border-primary table-bordered">
                        <thead>
                            <tr style={{backgroundColor:" #99e6ff"}}>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Profile Picture</th>
                                <th>Contact</th>
                                <th>Email</th>
                                <th>Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            {rowArr}
                        </tbody>
                    </table> : <br />
                }
            </div>
        )
    }
}

function renderPage() {
    return (
        <div>
            <Form />
            <br/>
            <Table />
        </div>
    )
}

export default renderPage;


